int abs (int a);
double dabs (double a);
int max (int a, int b);
double potencia (double a, int b);