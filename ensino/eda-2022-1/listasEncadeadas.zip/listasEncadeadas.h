typedef struct no {
    int dado;
    struct no *prox;
} no;

no *criaLista ();
int insereLista (no *p, int x);
int removeLista (no *p, int *y);
void imprimeLista (no *le);
void destroiLista (no *le);

// busca o elemento x na lista e devolve o no que o contem
// se x nao esta na lista, devolve NULL
no *buscaLista (no *le, int x);