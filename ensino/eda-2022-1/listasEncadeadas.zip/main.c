#include <stdio.h>
#include "listasEncadeadas.h"

int main () {
    int op, x;
    no *p, *le;
    
    le = malloc (sizeof (no));
    le->prox = NULL;

    do {
        printf ("\nEscolha uma opcao:\n");
        printf ("1. Inserir no inicio\n");
        printf ("2. Inserir depois de um dado\n");
        printf ("3. Remover do inicio\n");
        printf ("4. Remover depois de um dado\n");
        printf ("5. Imprimir a lista\n");
        printf ("6. Sair\n");
        scanf ("%d", &op);

        switch (op) {
            case 1:
                printf ("Digite o dado a ser inserido: ");
                scanf ("%d", &x);
                insereLista (le, x);
                imprimeLista (le);
                break;
            case 2:
                printf ("Digite o valor do dado: ");
                scanf ("%d", &x);
                p = buscaLista (le, x);
                if (p != NULL) {
                    printf ("Digite o valor a ser inserido: ");
                    scanf ("%d", &x);
                    insereLista (p, x);
                }
                else {
                    printf ("O valor nao pertence a lista.\n");
                }
                imprimeLista (le);
                break;
            case 3:
                if (removeLista (p, &x))
                    printf ("Elemento removido: %d\n", x);
                else
                    printf ("Lista vazia\n");
                imprimeLista (le);
                break;
            case 4:
                printf ("Digite o valor do dado: ");
                scanf ("%d", &x);
                p = buscaLista (le, x);
                if (p != NULL) {
                    if (removeLista (p, &x))
                        printf ("Elemento removido: %d\n", x);
                    else
                        printf ("Lista vazia\n");
                }
                else {
                    printf ("O valor nao pertence a lista.\n");
                }
                imprimeLista (le);
                break;
            case 5:
                imprimeLista (le);
        }

    } while (op != 6);

    destroiLista (le);
    
    return 0;
}