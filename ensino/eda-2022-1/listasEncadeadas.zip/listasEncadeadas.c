#include <stdio.h>
#include <stdlib.h>
#include "listasEncadeadas.h"

no * criaLista () {
    no *le = malloc (sizeof (no));
    le->prox = NULL;
    return le;
}

int insereLista (no *p, int x) {
    no *novo = malloc (sizeof (no));
    if (novo == NULL) return 0;
    novo->dado = x;
    novo->prox = p->prox;
    p->prox = novo;
    return 1;
}

int removeLista (no *p, int *y) {
    no *lixo = p->prox;
    if (lixo == NULL) return 0;
    *y = lixo->dado;
    p->prox = lixo->prox;
    free (lixo);
    return 1;
}

void destroiLista (no *le) {
    int dummy;
    while (removeLista (le, &dummy));
    free (le);
}

void imprimeLista (no *le) {
    printf ("-----------------------------------------\n");
    printf ("le -> ");
    for (no *p = le->prox; p != NULL; p = p->prox)
        printf ("%d -> ", p->dado);
    printf ("NULL\n");
    printf ("-----------------------------------------\n");
}

no *buscaLista (no *le, int x) {
    no *p;
    for (p = le->prox; p != NULL && p->dado != x; p = p->prox);
    return p;
}