typedef struct {
    int *dado;
    int topo, N;
} pilha;

pilha *cria_pilha ();
int empilha (pilha *p, int x);
int desempilha (pilha *p, int *y);
void destroi_pilha (pilha *p);
void imprime_pilha (pilha *p);